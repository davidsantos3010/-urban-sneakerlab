-- URBAN.SNEAKERLAB — database schema
-- Designed for PostgreSQL/Supabase.
-- Run after creating a new database project.

create extension if not exists "pgcrypto";

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text,
  created_at timestamptz not null default now()
);

create table if not exists brands (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  brand_id uuid references brands(id) on delete set null,
  name text not null,
  slug text not null unique,
  description text,
  price_cents integer not null check (price_cents >= 0),
  compare_at_cents integer,
  color text,
  image_url text,
  active boolean not null default true,
  featured boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists product_sizes (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  size text not null,
  stock integer not null default 0 check (stock >= 0),
  unique(product_id, size)
);

create type order_status as enum (
  'pending_payment',
  'paid',
  'processing',
  'shipped',
  'delivered',
  'cancelled'
);

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  email text not null,
  status order_status not null default 'pending_payment',
  total_cents integer not null check (total_cents >= 0),
  shipping_name text not null,
  shipping_address text not null,
  shipping_city text not null,
  shipping_postcode text not null,
  shipping_country text not null,
  payment_reference text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid references products(id) on delete set null,
  product_name text not null,
  size text not null,
  quantity integer not null default 1 check (quantity > 0),
  unit_price_cents integer not null check (unit_price_cents >= 0)
);

-- Starter brands
insert into brands (name, slug) values
('Nike','nike'), ('Jordan','jordan'), ('adidas','adidas'),
('New Balance','new-balance'), ('Puma','puma'),
('ASICS','asics'), ('Vans','vans'), ('Converse','converse')
on conflict (slug) do nothing;

-- Useful indexes
create index if not exists products_brand_idx on products(brand_id);
create index if not exists products_active_idx on products(active);
create index if not exists product_sizes_product_idx on product_sizes(product_id);
create index if not exists orders_user_idx on orders(user_id);
create index if not exists orders_status_idx on orders(status);
create index if not exists order_items_order_idx on order_items(order_id);
