URBAN.SNEAKERLAB v7 — produção

Esta versão adiciona:
- RLS e políticas de segurança para Supabase
- perfis customer/admin
- criação automática de perfil após signup
- cliente Supabase para autenticação
- blueprint de Stripe Checkout + webhook
- separação explícita entre chaves públicas e segredos

Fontes oficiais usadas para a arquitetura:
Supabase Auth/Database/RLS e Stripe Checkout.

Para ativar de verdade:
1. Criar o projeto Supabase.
2. Executar supabase_schema.sql.
3. Executar supabase_rls.sql.
4. Criar a conta admin e definir role='admin' no perfil.
5. Configurar as variáveis VITE_* no frontend.
6. Configurar as variáveis secretas no servidor.
7. Criar a conta Stripe e configurar o webhook.
8. Testar pagamentos em modo de teste.
9. Só depois publicar em produção.

Nenhuma chave real é incluída neste pacote.
