-- Depois de criares a tua conta na loja,
-- descobre o teu email/ID em Authentication > Users.
-- Substitui EMAIL_AQUI pelo teu email e executa.
update public.profiles
set role = 'admin'
where id = (
  select id from auth.users where email = 'EMAIL_AQUI'
);

select id, full_name, role
from public.profiles
where role = 'admin';
