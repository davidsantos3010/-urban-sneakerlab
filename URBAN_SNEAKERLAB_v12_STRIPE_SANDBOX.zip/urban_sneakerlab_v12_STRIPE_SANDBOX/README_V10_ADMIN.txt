URBAN.SNEAKERLAB v10 — PAINEL ADMIN

O admin.html agora tem:
- login Supabase;
- verificação de role=admin;
- lista de produtos;
- criar/editar produto;
- preço e preço anterior;
- marca, cor e imagem;
- tamanhos e stock;
- ativar/desativar;
- destaque;
- lista de encomendas;
- alteração de estado da encomenda.

Para criar o primeiro administrador:
1. Cria uma conta normal na loja.
2. No Supabase > Authentication > Users, encontra o email.
3. Abre o SQL Editor.
4. Usa TORNAR_ADMIN.sql, substituindo EMAIL_AQUI pelo teu email.
5. Volta ao admin.html e entra com a tua conta.

Não coloque secret/service_role keys no frontend.
