-- URBAN.SNEAKERLAB — catálogo inicial de demonstração
-- Os produtos abaixo são MOCK/DEMO. Não representam stock real nem afiliação oficial.

insert into products
  (brand_id, name, slug, description, price_cents, compare_at_cents, color, image_url, active, featured)
select
  b.id, v.name, v.slug, v.description, v.price_cents, v.compare_at_cents,
  v.color, v.image_url, true, v.featured
from (values
  ('Nike','Nike Air Max Pulse','nike-air-max-pulse','DEMO — substituir por produto/stock real.',14999,16999,'Black / White','',true),
  ('Nike','Nike Air Force 1 Low','nike-air-force-1-low','DEMO — substituir por produto/stock real.',11999,13999,'White','',true),
  ('Nike','Nike Dunk Low','nike-dunk-low','DEMO — substituir por produto/stock real.',12999,14999,'Grey / White','',true),
  ('Jordan','Air Jordan 1 Low','air-jordan-1-low','DEMO — substituir por produto/stock real.',13999,15999,'Black / Red','',true),
  ('Jordan','Air Jordan 1 Mid','air-jordan-1-mid','DEMO — substituir por produto/stock real.',15999,17999,'White / Black','',true),
  ('Jordan','Jordan 4 Retro','jordan-4-retro','DEMO — substituir por produto/stock real.',20999,22999,'Black / Grey','',true),
  ('adidas','adidas Campus 00s','adidas-campus-00s','DEMO — substituir por produto/stock real.',10999,12999,'Green / White','',true),
  ('adidas','adidas Samba OG','adidas-samba-og','DEMO — substituir por produto/stock real.',11999,13999,'White / Black','',true),
  ('adidas','adidas Gazelle Indoor','adidas-gazelle-indoor','DEMO — substituir por produto/stock real.',11999,13999,'Blue / White','',true),
  ('New Balance','New Balance 530','new-balance-530','DEMO — substituir por produto/stock real.',11999,13999,'Silver / White','',true),
  ('New Balance','New Balance 550','new-balance-550','DEMO — substituir por produto/stock real.',12999,14999,'White / Green','',true),
  ('New Balance','New Balance 9060','new-balance-9060','DEMO — substituir por produto/stock real.',16999,18999,'Cream / Grey','',true),
  ('Puma','Puma Palermo','puma-palermo','DEMO — substituir por produto/stock real.',8999,10999,'White / Blue','',false),
  ('Puma','Puma Suede Classic','puma-suede-classic','DEMO — substituir por produto/stock real.',8499,9999,'Black / White','',false),
  ('Puma','Puma Speedcat','puma-speedcat','DEMO — substituir por produto/stock real.',9999,11999,'Red / White','',false),
  ('ASICS','ASICS GEL-1130','asics-gel-1130','DEMO — substituir por produto/stock real.',11999,13999,'White / Silver','',true),
  ('ASICS','ASICS GEL-Kayano 14','asics-gel-kayano-14','DEMO — substituir por produto/stock real.',15999,17999,'Silver / Black','',true),
  ('Vans','Vans Old Skool','vans-old-skool','DEMO — substituir por produto/stock real.',7499,8999,'Black / White','',false),
  ('Vans','Vans Knu Skool','vans-knu-skool','DEMO — substituir por produto/stock real.',8999,10499,'Black','',false),
  ('Converse','Converse Chuck 70','converse-chuck-70','DEMO — substituir por produto/stock real.',8999,10499,'Black / White','',false)
) as v(brand_name,name,slug,description,price_cents,compare_at_cents,color,image_url,featured)
join brands b on b.name = v.brand_name
on conflict (slug) do nothing;

-- Tamanhos e stock DEMO.
-- Reexecutar este bloco não cria duplicados.
insert into product_sizes (product_id, size, stock)
select p.id, s.size, 5
from products p
cross join (values ('36'),('37'),('38'),('39'),('40'),('41'),('42'),('43'),('44'),('45')) as s(size)
where p.slug in (
  'nike-air-max-pulse','nike-air-force-1-low','nike-dunk-low',
  'air-jordan-1-low','air-jordan-1-mid','jordan-4-retro',
  'adidas-campus-00s','adidas-samba-og','adidas-gazelle-indoor',
  'new-balance-530','new-balance-550','new-balance-9060',
  'puma-palermo','puma-suede-classic','puma-speedcat',
  'asics-gel-1130','asics-gel-kayano-14',
  'vans-old-skool','vans-knu-skool','converse-chuck-70'
)
on conflict (product_id, size) do nothing;

select count(*) as produtos_demo from products
where slug in (
  'nike-air-max-pulse','nike-air-force-1-low','nike-dunk-low',
  'air-jordan-1-low','air-jordan-1-mid','jordan-4-retro',
  'adidas-campus-00s','adidas-samba-og','adidas-gazelle-indoor',
  'new-balance-530','new-balance-550','new-balance-9060',
  'puma-palermo','puma-suede-classic','puma-speedcat',
  'asics-gel-1130','asics-gel-kayano-14',
  'vans-old-skool','vans-knu-skool','converse-chuck-70'
);
