# URBAN.SNEAKERLAB — backend contract

## Public
GET    /api/products
GET    /api/products/:slug
GET    /api/brands

## Customer
POST   /api/auth/signup
POST   /api/auth/login
GET    /api/me
GET    /api/me/orders
GET    /api/me/orders/:id

## Checkout
POST   /api/checkout/session
POST   /api/webhooks/payment

## Admin
GET    /api/admin/products
POST   /api/admin/products
PATCH  /api/admin/products/:id
DELETE /api/admin/products/:id
GET    /api/admin/orders
PATCH  /api/admin/orders/:id/status

## Security requirements
- Validate every request server-side.
- Never trust price, stock, or total sent by the browser.
- Recalculate cart totals from database records.
- Reserve/decrement stock atomically during order creation.
- Verify payment webhooks cryptographically.
- Admin routes require authenticated admin role.
- Do not expose service-role database credentials to the browser.
