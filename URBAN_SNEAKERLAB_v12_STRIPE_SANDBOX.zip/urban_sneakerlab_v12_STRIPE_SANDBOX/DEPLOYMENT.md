# Publicação da URBAN.SNEAKERLAB

1. Criar um projeto PostgreSQL/Supabase.
2. Executar `supabase_schema.sql`.
3. Configurar autenticação por email.
4. Criar storage privado/público para imagens de produtos.
5. Implementar API/servidor com as variáveis de `env.example`.
6. Ligar um processador de pagamentos (ex.: Stripe) no servidor.
7. Configurar webhook de pagamento.
8. Definir a conta de administrador e proteger as rotas `/api/admin/*`.
9. Publicar o frontend.
10. Apontar o domínio da loja para o hosting.

Importante: o schema e contrato desta pasta são a base técnica. A loja v4 continua funcionando como demonstração local; estes ficheiros preparam a migração para produção.
