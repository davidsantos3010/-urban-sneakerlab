
-- URBAN.SNEAKERLAB production security layer
-- Run AFTER supabase_schema.sql

alter table profiles enable row level security;
alter table brands enable row level security;
alter table products enable row level security;
alter table product_sizes enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;

-- Public storefront
create policy "public can read active products"
on products for select
to anon, authenticated
using (active = true);

create policy "public can read brands"
on brands for select
to anon, authenticated
using (true);

create policy "public can read sizes for active products"
on product_sizes for select
to anon, authenticated
using (exists (
  select 1 from products p
  where p.id = product_sizes.product_id and p.active = true
));

-- Customer profile: only the owner
create policy "users read own profile"
on profiles for select
to authenticated
using (id = auth.uid());

create policy "users update own profile"
on profiles for update
to authenticated
using (id = auth.uid())
with check (id = auth.uid());

-- Customers can read their own orders/items.
create policy "users read own orders"
on orders for select
to authenticated
using (user_id = auth.uid());

create policy "users read own order items"
on order_items for select
to authenticated
using (exists (
  select 1 from orders o
  where o.id = order_items.order_id
    and o.user_id = auth.uid()
));

-- Admin access should be granted via a profiles.role value.
alter table profiles add column if not exists role text not null default 'customer';
create index if not exists profiles_role_idx on profiles(role);

create policy "admins manage products"
on products for all
to authenticated
using (exists (select 1 from profiles p where p.id=auth.uid() and p.role='admin'))
with check (exists (select 1 from profiles p where p.id=auth.uid() and p.role='admin'));

create policy "admins manage sizes"
on product_sizes for all
to authenticated
using (exists (select 1 from profiles p where p.id=auth.uid() and p.role='admin'))
with check (exists (select 1 from profiles p where p.id=auth.uid() and p.role='admin'));

create policy "admins manage orders"
on orders for all
to authenticated
using (exists (select 1 from profiles p where p.id=auth.uid() and p.role='admin'))
with check (exists (select 1 from profiles p where p.id=auth.uid() and p.role='admin'));

create policy "admins manage order items"
on order_items for all
to authenticated
using (exists (select 1 from profiles p where p.id=auth.uid() and p.role='admin'))
with check (exists (select 1 from profiles p where p.id=auth.uid() and p.role='admin'));

-- New auth users automatically get a customer profile.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();
