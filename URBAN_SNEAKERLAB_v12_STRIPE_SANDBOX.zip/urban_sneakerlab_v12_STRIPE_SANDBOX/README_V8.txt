URBAN.SNEAKERLAB v8

O que foi acrescentado:
- Frontend preparado para Supabase.
- Produtos podem ser carregados da tabela products quando Supabase estiver configurado.
- Registo/login real via Supabase Auth.
- Perfil do cliente e histórico de encomendas via Supabase.
- Criação de encomenda online na tabela orders/order_items.
- Continua a existir modo demonstração quando config.js está vazio.
- Mantém a camada RLS criada na v7.
- Stripe continua separado e server-side; esta versão NÃO processa pagamentos reais.

COMO CONFIGURAR:
1. Copia config.example.js para config.js.
2. No Supabase, cria um projeto.
3. Executa supabase_schema.sql e depois supabase_rls.sql no SQL Editor.
4. Em Project Settings -> API, copia:
   - Project URL
   - Publishable key (ou anon key, conforme o projeto)
   para config.js.
5. Abre index.html através de um servidor local (não uses file://).

IMPORTANTE:
- Nunca colocar SUPABASE_SECRET_KEY/service role no navegador.
- Nunca colocar STRIPE_SECRET_KEY no navegador.
- Antes do lançamento real, configurar domínio, emails de autenticação, políticas legais, entregas/impostos e Stripe Webhooks.


CONFIGURAÇÃO ATUAL: o config.js desta cópia já contém o Project URL e a Publishable Key fornecidos pelo proprietário do projeto.
