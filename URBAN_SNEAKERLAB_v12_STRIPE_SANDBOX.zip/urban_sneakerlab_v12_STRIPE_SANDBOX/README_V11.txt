URBAN.SNEAKERLAB v11 — experiência de loja simplificada

Foco:
- pesquisa rápida
- filtros por marca
- catálogo conectado ao Supabase
- tamanhos e stock
- carrinho
- conta do cliente
- visual mobile
- painel admin continua incluído

Os produtos atuais continuam DEMO.
Stripe ainda não está ativo.
